# 微信AI助手 (WeChat AI Assistant) - GitHub云编译指南

这是一个Xposed模块项目，用于增强微信功能。由于AIDE Pro编译可能存在环境问题，本指南提供GitHub云编译方案。

## 📦 GitHub云编译步骤

### 1. 创建GitHub仓库
1. 访问 https://github.com/new
2. 创建新仓库，例如 `wechat-ai-assistant`
3. 选择"Public"或"Private"
4. 不要初始化README、.gitignore或LICENSE

### 2. 上传项目到GitHub
如果你有Git命令行工具：
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/你的用户名/wechat-ai-assistant.git
git push -u origin main
```

如果没有Git工具，可以：
1. 在GitHub仓库页面点击"Add file" → "Upload files"
2. 上传整个项目文件夹
3. 提交更改

### 3. 触发云编译
1. 进入仓库的"Actions"标签页
2. 选择"Android Build"工作流
3. 点击"Run workflow"手动触发
4. 等待编译完成（约2-5分钟）

### 4. 下载APK
1. 编译完成后，点击该次运行
2. 在"Artifacts"部分下载`debug-apk.zip`
3. 解压得到APK文件

## 🔧 本地编译问题排查

如果GitHub云编译也失败，可能是代码问题：

### 常见问题
1. **依赖缺失** - 检查`app/build.gradle`中的依赖
2. **AndroidManifest冲突** - 检查Activity声明
3. **Java版本不兼容** - 确保使用Java 8或11
4. **Xposed API缺失** - 确保`libs/compile_only/xposed-api-82_compileonly.jar`存在

### 快速测试
运行测试脚本检查项目完整性：
```bash
chmod +x test_compile.sh
./test_compile.sh
```

## 📁 项目结构
```
微信ai助手/
├── .github/workflows/android-build.yml  # GitHub Actions配置
├── app/
│   ├── src/main/java/com/wxai/appzs/    # 源代码
│   ├── src/main/res/                    # 资源文件
│   ├── libs/compile_only/               # Xposed API JAR
│   └── build.gradle                     # 模块构建配置
├── build.gradle                         # 项目构建配置
├── settings.gradle                      # 项目设置
├── gradle.properties                    # Gradle属性
├── local.properties                     # 本地SDK配置
├── test_compile.sh                      # 测试脚本
└── README.md                            # 本文件
```

## ⚙️ 技术要求
- **Android SDK**: 33
- **Java版本**: 11
- **Gradle版本**: 7.0.2
- **Xposed API**: 82 (编译时依赖)

## 📝 注意事项
1. GitHub Actions使用Ubuntu环境，可能比AIDE Pro更稳定
2. 确保项目中没有敏感信息（API密钥等）
3. 云编译生成的APK可直接安装测试
4. 如果编译失败，检查GitHub Actions日志获取详细错误

## 🚀 快速开始
1. 将项目上传到GitHub
2. 触发云编译
3. 下载APK安装到手机
4. 在LSPosed中激活模块
5. 配置API密钥并启用

## 🤝 贡献
欢迎提交Issue和Pull Request来改进项目。

## ⚠️ 免责声明
本项目仅供学习研究使用，请遵守微信用户协议和相关法律法规。