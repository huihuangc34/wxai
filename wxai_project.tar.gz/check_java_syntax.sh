#!/bin/sh
echo "=== Java文件语法检查 ==="
echo ""

cd "$(dirname "$0")"

check_java_file() {
    local file="$1"
    echo "检查: $file"
    
    # 检查文件是否存在
    if [ ! -f "$file" ]; then
        echo "  ✗ 文件不存在"
        return 1
    fi
    
    # 检查是否有package声明
    if ! head -5 "$file" | grep -q "^package "; then
        echo "  ⚠️  缺少package声明"
    fi
    
    # 检查类定义
    if ! grep -q "^public class\|^class\|^public abstract class\|^public interface" "$file"; then
        echo "  ⚠️  缺少类定义"
    fi
    
    # 检查括号是否匹配
    open_braces=$(grep -o "{" "$file" | wc -l)
    close_braces=$(grep -o "}" "$file" | wc -l)
    
    if [ "$open_braces" -eq "$close_braces" ]; then
        echo "  ✓ 括号匹配: {=$open_braces }=$close_braces"
    else
        echo "  ✗ 括号不匹配: {=$open_braces }=$close_braces"
    fi
    
    # 检查文件是否以}结尾
    last_char=$(tail -c 1 "$file" | od -An -t x1 | tr -d ' \n')
    if [ "$last_char" = "7d" ]; then
        echo "  ✓ 以}结尾"
    else
        echo "  ✗ 不以}结尾 (最后字符: 0x$last_char)"
    fi
    
    echo ""
}

# 检查所有Java文件
for java_file in app/src/main/java/com/wxai/appzs/*.java; do
    if [ -f "$java_file" ]; then
        check_java_file "$java_file"
    fi
done

echo "=== 检查完成 ==="
echo ""
echo "如果所有文件都有 ✓，说明Java语法基本正确。"
echo "如果有 ✗ 标记，需要修复对应问题。"