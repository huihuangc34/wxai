#!/bin/bash

# 微信AI助手项目打包脚本
# 此脚本将项目打包成可直接上传到GitHub的格式

set -e

echo "=== 微信AI助手项目打包脚本 ==="
echo "开始时间: $(date)"
echo ""

# 项目根目录
PROJECT_DIR="/storage/emulated/0/AideProjects/微信ai助手"
BACKUP_DIR="/storage/emulated/0/AideProjects/wxai_backup_$(date +%Y%m%d_%H%M%S)"
OUTPUT_DIR="/storage/emulated/0/AideProjects/wxai_release"

echo "1. 检查项目结构..."
if [ ! -d "$PROJECT_DIR" ]; then
    echo "错误: 项目目录不存在: $PROJECT_DIR"
    exit 1
fi

echo "2. 创建备份目录: $BACKUP_DIR"
mkdir -p "$BACKUP_DIR"

echo "3. 复制项目文件..."
cp -r "$PROJECT_DIR/"* "$BACKUP_DIR/" 2>/dev/null || true

echo "4. 清理不必要的文件..."
find "$BACKUP_DIR" -name "*.orig" -delete
find "$BACKUP_DIR" -name "*.backup" -delete
find "$BACKUP_DIR" -name "*.log" -delete
rm -rf "$BACKUP_DIR/build" 2>/dev/null || true
rm -rf "$BACKUP_DIR/.gradle" 2>/dev/null || true
rm -rf "$BACKUP_DIR/.idea" 2>/dev/null || true

echo "5. 创建发布目录: $OUTPUT_DIR"
mkdir -p "$OUTPUT_DIR"

echo "6. 创建压缩包..."
cd "$BACKUP_DIR/.."
tar -czf "$OUTPUT_DIR/wxai_project_full.tar.gz" "$(basename "$BACKUP_DIR")"

echo "7. 创建最小化版本（仅源代码）..."
mkdir -p "$OUTPUT_DIR/wxai_minimal"
cp -r "$BACKUP_DIR/app/src" "$OUTPUT_DIR/wxai_minimal/"
cp -r "$BACKUP_DIR/app/libs" "$OUTPUT_DIR/wxai_minimal/" 2>/dev/null || true
cp "$BACKUP_DIR/app/build.gradle" "$OUTPUT_DIR/wxai_minimal/"
cp "$BACKUP_DIR/app/AndroidManifest.xml" "$OUTPUT_DIR/wxai_minimal/"
cp "$BACKUP_DIR/build.gradle" "$OUTPUT_DIR/wxai_minimal/"
cp "$BACKUP_DIR/settings.gradle" "$OUTPUT_DIR/wxai_minimal/"
cp "$BACKUP_DIR/gradle.properties" "$OUTPUT_DIR/wxai_minimal/"
cp "$BACKUP_DIR/README.md" "$OUTPUT_DIR/wxai_minimal/"

echo "8. 创建GitHub Actions工作流..."
mkdir -p "$OUTPUT_DIR/wxai_minimal/.github/workflows"
cat > "$OUTPUT_DIR/wxai_minimal/.github/workflows/android-build.yml" << 'EOF'
name: Android Build

on:
  push:
    branches: [ main, master ]
  pull_request:
    branches: [ main, master ]

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
    - uses: actions/checkout@v3
    
    - name: Set up JDK 11
      uses: actions/setup-java@v3
      with:
        java-version: '11'
        distribution: 'temurin'
        
    - name: Grant execute permission for gradlew
      run: chmod +x gradlew
      
    - name: Build with Gradle
      run: ./gradlew assembleDebug
      
    - name: Upload APK
      uses: actions/upload-artifact@v3
      with:
        name: app-debug
        path: app/build/outputs/apk/debug/
EOF

echo "9. 创建压缩包..."
cd "$OUTPUT_DIR"
tar -czf "wxai_minimal.tar.gz" "wxai_minimal"

echo "10. 生成项目清单..."
cat > "$OUTPUT_DIR/PROJECT_SUMMARY.md" << 'EOF'
# 微信AI助手项目 - 打包总结

## 项目信息
- 项目名称: 微信AI助手
- 打包时间: $(date)
- 项目目录: /storage/emulated/0/AideProjects/微信ai助手

## 文件清单

### 完整版本
- 文件: wxai_project_full.tar.gz
- 大小: $(du -h "$OUTPUT_DIR/wxai_project_full.tar.gz" | cut -f1)
- 内容: 完整项目文件，包括所有配置和文档

### 最小化版本
- 文件: wxai_minimal.tar.gz
- 大小: $(du -h "$OUTPUT_DIR/wxai_minimal.tar.gz" | cut -f1)
- 内容: 仅源代码和必要配置文件

## GitHub上传指南

### 方法1: 使用Git命令
1. 访问 https://github.com/huihuangc34/wxai
2. 如果仓库不存在，点击 "New repository" 创建
3. 获取GitHub个人访问令牌: https://github.com/settings/tokens
4. 使用以下命令推送:

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/huihuangc34/wxai.git
# 使用令牌推送
git push -u origin master
```

### 方法2: 网页上传
1. 访问 https://github.com/huihuangc34/wxai
2. 点击 "Add file" → "Upload files"
3. 上传压缩包内容

## 编译说明
项目已配置GitHub Actions自动编译，推送后会自动构建APK。

## 文件结构
```
wxai_minimal/
├── .github/workflows/android-build.yml  # GitHub Actions配置
├── app/src/main/                        # 源代码
├── app/build.gradle                     # 模块构建配置
├── app/AndroidManifest.xml              # Android清单
├── build.gradle                         # 项目构建配置
├── settings.gradle                      # Gradle设置
├── gradle.properties                    # Gradle属性
└── README.md                            # 项目说明
```
EOF

echo "11. 打包完成！"
echo ""
echo "=== 打包结果 ==="
echo "完整版本: $OUTPUT_DIR/wxai_project_full.tar.gz"
echo "最小版本: $OUTPUT_DIR/wxai_minimal.tar.gz"
echo "项目清单: $OUTPUT_DIR/PROJECT_SUMMARY.md"
echo ""
echo "文件大小:"
ls -lh "$OUTPUT_DIR"/*.tar.gz
echo ""
echo "下一步:"
echo "1. 上传压缩包到GitHub"
echo "2. 或运行 push_to_github.sh 脚本自动推送"
echo ""
echo "GitHub仓库: https://github.com/huihuangc34/wxai"