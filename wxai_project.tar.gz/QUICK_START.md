# 🚀 微信AI助手 - 5分钟快速云编译

## 只需5步，无需AIDE Pro！

### 第1步：检查项目（1分钟）
在Termux或文件管理器中：
```bash
cd /storage/emulated/0/AideProjects/微信ai助手
sh compile_check.sh
```
**确认**：所有项目结构显示 ✓

### 第2步：打包项目（1分钟）
```bash
sh package_project.sh
```
**结果**：在 `/storage/emulated/0/` 生成 `wechat-ai-assistant.zip`

### 第3步：创建GitHub仓库（1分钟）
1. 用浏览器访问：https://github.com/new
2. 仓库名：`wechat-ai-assistant`
3. **重要**：不要勾选"Initialize this repository with..."
4. 点击"Create repository"

### 第4步：上传文件（1分钟）
1. 在新仓库页面点击"Add file" → "Upload files"
2. 上传 `wechat-ai-assistant.zip`
3. GitHub会自动解压
4. 点击"Commit changes"

### 第5步：触发编译（1分钟）
1. 点击仓库的"Actions"标签页
2. 点击"Android Build"
3. 点击"Run workflow" → "Run workflow"
4. 等待2-5分钟

## 🎉 完成！
编译成功后：
1. 在"Artifacts"下载APK
2. 安装到手机
3. 在LSPosed中激活模块

## 📞 遇到问题？
1. **截图错误信息**
2. **分享GitHub仓库链接**
3. **我会帮你解决**

**现在就开始吧！** ⏱️