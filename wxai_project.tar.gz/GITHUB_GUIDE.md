# GitHub云编译完整指南

## 方案选择

### 方案A：使用Termux（推荐）
如果你的手机安装了Termux，可以直接在手机上操作：
1. 在Termux中：`pkg install git`
2. 进入项目目录：`cd /storage/emulated/0/AideProjects/微信ai助手`
3. 运行：`bash git_init.sh`
4. 按照脚本提示操作

### 方案B：使用电脑
1. 将项目文件夹复制到电脑
2. 在电脑上安装Git
3. 运行`git_init.sh`脚本
4. 推送到GitHub

### 方案C：网页上传（最简单）
1. 将项目文件夹压缩为zip文件
2. 访问 https://github.com/new 创建新仓库
3. 在仓库页面点击"Add file" → "Upload files"
4. 上传zip文件，GitHub会自动解压

## 详细步骤

### 第一步：创建GitHub仓库
1. 访问 https://github.com/new
2. 填写仓库名称，如：`wechat-ai-assistant`
3. 描述可选：`微信AI助手Xposed模块`
4. 选择Public或Private
5. **重要**：不要勾选"Initialize this repository with..."
6. 点击"Create repository"

### 第二步：上传代码
#### 方法1：命令行（需要Git）
```bash
# 在项目目录中执行
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/你的用户名/wechat-ai-assistant.git
git push -u origin main
```

#### 方法2：网页上传
1. 在GitHub仓库页面，点击"Add file" → "Upload files"
2. 拖拽整个项目文件夹或选择所有文件
3. 点击"Commit changes"

### 第三步：触发云编译
1. 进入仓库的"Actions"标签页
2. 点击"Android Build"工作流
3. 点击"Run workflow" → "Run workflow"
4. 等待约2-5分钟

### 第四步：下载APK
1. 编译完成后，点击绿色的"✓"标记
2. 滚动到页面底部"Artifacts"部分
3. 点击"debug-apk"下载zip文件
4. 解压得到APK文件

## 故障排除

### 编译失败常见原因
1. **依赖问题**：检查`app/build.gradle`中的依赖项
2. **Java版本**：GitHub Actions使用Java 11，确保代码兼容
3. **Xposed API**：确保`libs/compile_only/xposed-api-82_compileonly.jar`文件存在
4. **AndroidManifest**：检查是否有重复的Activity声明

### 查看错误日志
1. 在GitHub Actions页面点击失败的运行
2. 查看"Build with Gradle"步骤的输出
3. 根据错误信息调整代码

## 项目文件说明

### 必须上传的文件
```
微信ai助手/
├── .github/workflows/android-build.yml  # GitHub Actions配置
├── app/                                  # Android应用模块
│   ├── src/main/                        # 源代码和资源
│   ├── libs/                            # 第三方库
│   └── build.gradle                     # 模块配置
├── build.gradle                         # 项目配置
├── settings.gradle                      # 项目设置
├── gradle.properties                    # Gradle属性
├── gradlew                              # Gradle包装器
└── gradlew.bat                          # Windows Gradle包装器
```

### 可选文件
- `backup_20260402_042416/` - 备份文件夹，可不传
- `test_compile.sh` - 测试脚本，可不传
- `*.md` - 文档文件

## 注意事项

### 安全性
1. **不要上传敏感信息**：如API密钥、密码等
2. **检查.gitignore**：确保不包含敏感文件
3. **使用Private仓库**：如果包含敏感代码

### 性能优化
1. **清理缓存**：上传前可删除`app/build/`目录
2. **压缩图片**：减少仓库大小
3. **分模块上传**：如果文件太多

## 后续维护

### 更新代码
```bash
git add .
git commit -m "更新描述"
git push
```

### 自动编译
每次推送到main分支都会自动触发编译

### 版本管理
建议使用Git标签管理版本：
```bash
git tag v1.0.0
git push origin v1.0.0
```

## 技术支持

如果GitHub云编译仍然失败：
1. 截图GitHub Actions的错误日志
2. 检查项目中的`COMPILE_CHECK.md`和`FINAL_CHECK.md`
3. 尝试简化项目结构
4. 创建一个最小可复现版本

## 备用方案

如果GitHub编译失败，还可以尝试：
1. **GitLab CI/CD**：类似的云编译服务
2. **Bitrise**：专业的移动应用CI/CD
3. **Jenkins**：自建编译服务器
4. **Travis CI**：另一个CI/CD服务

---

**重要提示**：云编译成功后，将APK安装到手机，在LSPosed中激活模块，然后配置API密钥即可使用。