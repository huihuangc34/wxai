#!/bin/bash

# GitHub推送脚本
# 使用方法: 
# 1. 先在GitHub上创建仓库: https://github.com/huihuangc34/wxai
# 2. 获取GitHub个人访问令牌: https://github.com/settings/tokens
# 3. 运行此脚本: bash push_to_github.sh

set -e

echo "=== GitHub推送脚本 ==="
echo "仓库: huihuangc34/wxai"
echo ""

# 检查是否已初始化Git
if [ ! -d ".git" ]; then
    echo "初始化Git仓库..."
    git init
    git config user.name "huihuangc34"
    git config user.email "huihuangc34@github.com"
fi

# 添加远程仓库
echo "设置远程仓库..."
git remote remove origin 2>/dev/null || true
git remote add origin https://github.com/huihuangc34/wxai.git

# 添加所有文件
echo "添加文件到Git..."
git add .

# 提交更改
echo "提交更改..."
git commit -m "Initial commit: WeChat AI Assistant project" || echo "没有新更改"

# 推送代码
echo "推送到GitHub..."
echo "注意: 需要GitHub个人访问令牌(PAT)"
echo "请访问: https://github.com/settings/tokens 创建令牌"
echo "然后使用以下命令推送:"
echo "git push -u origin master"
echo ""
echo "或者使用HTTPS凭据推送:"
echo "git push https://huihuangc34:YOUR_TOKEN@github.com/huihuangc34/wxai.git master"

# 尝试推送
echo "正在尝试推送..."
git push -u origin master || {
    echo ""
    echo "推送失败！请按以下步骤操作:"
    echo "1. 访问 https://github.com/huihuangc34/wxai"
    echo "2. 如果仓库不存在，请先创建"
    echo "3. 获取个人访问令牌"
    echo "4. 重新运行此脚本"
    echo ""
    echo "备用方案: 手动上传压缩包"
    echo "压缩包已创建: /storage/emulated/0/AideProjects/wxai_project.tar.gz"
}