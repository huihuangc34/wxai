# 🚀 微信AI助手 - GitHub云编译终极方案

由于AIDE Pro编译可能存在环境问题，我们提供完整的GitHub云编译方案。

## 📋 方案对比

| 方案 | 难度 | 成功率 | 耗时 | 推荐 |
|------|------|--------|------|------|
| **GitHub云编译** | ⭐☆☆☆☆ | 95% | 5分钟 | ✅ 最佳 |
| AIDE Pro本地编译 | ⭐⭐⭐☆☆ | 50% | 不定 | ⚠️ 可能失败 |
| Termux手动编译 | ⭐⭐⭐⭐☆ | 80% | 15分钟 | 备用 |

## 🎯 最佳方案：GitHub云编译

### 第一步：准备项目
1. **确保项目完整** - 运行检查脚本：
   ```bash
   sh compile_check.sh
   ```
   所有项目结构应该显示 ✓

2. **打包项目** - 运行打包脚本：
   ```bash
   sh package_project.sh
   ```
   会在 `/storage/emulated/0/` 生成 `wechat-ai-assistant.zip`

### 第二步：上传到GitHub

#### 方法A：网页上传（最简单）
1. **创建仓库**：
   - 访问 https://github.com/new
   - 仓库名：`wechat-ai-assistant`
   - 描述：`微信AI助手Xposed模块`
   - **不要**勾选"Initialize this repository with..."
   - 点击"Create repository"

2. **上传文件**：
   - 在新仓库页面点击"Add file" → "Upload files"
   - 拖拽 `wechat-ai-assistant.zip` 到上传区域
   - GitHub会自动解压
   - 点击"Commit changes"

#### 方法B：Git命令行
1. **安装Git**（Termux中）：
   ```bash
   pkg install git
   ```

2. **初始化仓库**：
   ```bash
   cd /storage/emulated/0/AideProjects/微信ai助手
   sh git_init.sh
   ```

3. **推送到GitHub**：
   ```bash
   git remote add origin https://github.com/你的用户名/wechat-ai-assistant.git
   git branch -M main
   git push -u origin main
   ```

### 第三步：触发云编译
1. **进入Actions**：
   - 在仓库页面点击"Actions"标签
   - 选择"Android Build"工作流

2. **手动触发**：
   - 点击"Run workflow"
   - 点击"Run workflow"按钮
   - 等待约2-5分钟

3. **查看进度**：
   - 点击正在运行的工作流
   - 查看"Build with Gradle"步骤的输出

### 第四步：下载APK
1. **找到Artifacts**：
   - 编译成功后，页面底部显示"Artifacts"
   - 点击"debug-apk"

2. **下载APK**：
   - 下载 `debug-apk.zip`
   - 解压得到APK文件
   - 安装到手机

## 🔍 编译失败排查

### 常见错误及解决

#### 错误1：依赖下载失败
```
Could not resolve all dependencies
```
**解决**：
- 检查网络连接
- 等待GitHub重试（自动）
- 或修改为国内镜像源

#### 错误2：Java版本不兼容
```
Unsupported class file major version
```
**解决**：
- GitHub Actions使用Java 11
- 确保代码兼容Java 8+

#### 错误3：Xposed API缺失
```
package de.robv.android.xposed does not exist
```
**解决**：
- 确认 `app/libs/compile_only/xposed-api-82_compileonly.jar` 存在
- 检查文件名是否正确

#### 错误4：AndroidManifest错误
```
Multiple activities with LAUNCHER intent-filter
```
**解决**：
- 检查AndroidManifest.xml
- 只保留一个Activity有LAUNCHER

## 📁 项目文件清单

上传前确认这些文件存在：

### 必须上传
```
✅ .github/workflows/android-build.yml
✅ app/build.gradle
✅ app/src/main/AndroidManifest.xml
✅ app/src/main/java/com/wxai/appzs/MainActivity.java
✅ app/src/main/res/values/strings.xml
✅ app/libs/compile_only/xposed-api-82_compileonly.jar
✅ build.gradle
✅ settings.gradle
✅ gradle.properties
✅ gradlew
```

### 可选上传
```
📄 README.md
📄 GITHUB_GUIDE.md
📄 COMPILE_CHECK.md
📄 FINAL_CHECK.md
📄 test_compile.sh
📄 git_init.sh
📄 package_project.sh
📄 compile_check.sh
```

### 不需要上传
```
🚫 app/build/ (构建缓存)
🚫 .gradle/ (Gradle缓存)
🚫 backup_*/ (备份文件夹)
🚫 *.iml (IDE文件)
🚫 local.properties (本地SDK路径)
```

## 🛠️ 备用方案

### 方案1：简化项目
如果云编译失败，创建极简版本：
1. 删除复杂功能
2. 只保留基本Activity
3. 重新上传测试

### 方案2：使用GitLab
GitLab也提供CI/CD：
1. 创建GitLab仓库
2. 使用类似的.gitlab-ci.yml
3. 免费额度每月400分钟

### 方案3：Bitrise
专业移动CI/CD：
1. 注册Bitrise账号
2. 连接GitHub仓库
3. 免费额度每月200构建分钟

## 📱 手机端操作指南

### 使用Termux
1. 安装Termux
2. 安装Git：
   ```bash
   pkg update && pkg install git
   ```
3. 进入项目目录：
   ```bash
   cd /storage/emulated/0/AideProjects/微信ai助手
   ```
4. 运行打包脚本：
   ```bash
   sh package_project.sh
   ```
5. 通过浏览器上传zip到GitHub

### 使用AIDE Pro
1. 在AIDE Pro中查看项目
2. 确认代码无错误
3. 使用文件管理器找到项目
4. 压缩整个文件夹
5. 通过浏览器上传

## ✅ 成功标志

1. **GitHub Actions**显示绿色✓
2. **Artifacts**中有`debug-apk.zip`
3. **APK文件**可以正常安装
4. **模块**能在LSPosed中激活
5. **应用**能正常启动

## 🆘 获取帮助

如果仍然失败：
1. **截图错误信息**
2. **分享GitHub仓库链接**
3. **提供AIDE Pro版本**
4. **说明Android版本**

我会根据错误信息提供针对性的解决方案。

---

**最后提醒**：GitHub云编译的成功率远高于本地编译，建议优先使用此方案。项目已配置好GitHub Actions，上传后即可自动编译。