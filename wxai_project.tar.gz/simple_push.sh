#!/bin/sh

echo "=== 微信AI助手 - GitHub推送助手 ==="
echo "项目位置: /storage/emulated/0/AideProjects/微信ai助手"
echo "GitHub仓库: https://github.com/huihuangc34/wxai"
echo ""

echo "1. 检查Git状态..."
cd "/storage/emulated/0/AideProjects/微信ai助手"

if [ ! -d ".git" ]; then
    echo "初始化Git仓库..."
    git init
    echo "[user]" > .git/config
    echo "    name = huihuangc34" >> .git/config
    echo "    email = huihuangc34@github.com" >> .git/config
    echo "[remote \"origin\"]" >> .git/config
    echo "    url = https://github.com/huihuangc34/wxai.git" >> .git/config
    echo "    fetch = +refs/heads/*:refs/remotes/origin/*" >> .git/config
fi

echo "2. 添加文件..."
git add .

echo "3. 提交更改..."
git commit -m "Update: WeChat AI Assistant project" || echo "没有新更改"

echo "4. 推送准备..."
echo ""
echo "=== 重要: 需要GitHub个人访问令牌 ==="
echo "1. 访问: https://github.com/settings/tokens"
echo "2. 点击 'Generate new token'"
echo "3. 选择 'repo' 权限"
echo "4. 复制生成的令牌"
echo ""
echo "5. 使用以下命令推送:"
echo "   git push https://huihuangc34:你的令牌@github.com/huihuangc34/wxai.git master"
echo ""
echo "6. 或者手动上传压缩包:"
echo "   完整包: /storage/emulated/0/AideProjects/wxai_project.tar.gz"
echo "   最小包: /storage/emulated/0/AideProjects/wxai_minimal.tar.gz"
echo ""
echo "7. GitHub Actions会自动编译APK"
echo "   编译完成后，在Actions页面下载APK"

echo ""
echo "=== 项目文件清单 ==="
find . -name "*.java" -o -name "*.xml" -o -name "*.gradle" -o -name "*.md" | head -20