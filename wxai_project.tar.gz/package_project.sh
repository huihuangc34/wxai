#!/bin/bash
# 项目打包脚本
# 使用方法: bash package_project.sh

echo "=== 微信AI助手项目打包 ==="
echo ""

# 检查当前目录
if [ ! -f "build.gradle" ] || [ ! -d "app" ]; then
    echo "❌ 错误: 请在项目根目录运行此脚本"
    echo "当前目录: $(pwd)"
    exit 1
fi

# 创建临时目录
TEMP_DIR="/storage/emulated/0/temp_wechat_ai"
OUTPUT_ZIP="/storage/emulated/0/wechat-ai-assistant.zip"

echo "1. 清理临时目录..."
rm -rf "$TEMP_DIR"
mkdir -p "$TEMP_DIR"

echo "2. 复制项目文件..."
# 复制所有必要文件
cp -r . "$TEMP_DIR/"

echo "3. 清理不需要的文件..."
cd "$TEMP_DIR"
# 删除备份文件夹
rm -rf backup_*
# 删除构建缓存
rm -rf app/build/
rm -rf .gradle/
rm -rf build/
# 删除可能的临时文件
find . -name "*.log" -delete
find . -name "*.tmp" -delete
find . -name "*.bak" -delete

echo "4. 创建压缩包..."
cd /storage/emulated/0
zip -r "wechat-ai-assistant.zip" "temp_wechat_ai/" > /dev/null

echo "5. 清理临时文件..."
rm -rf "$TEMP_DIR"

echo ""
echo "✅ 打包完成！"
echo ""
echo "=== 文件信息 ==="
echo "压缩包: $OUTPUT_ZIP"
echo "大小: $(du -h "$OUTPUT_ZIP" | cut -f1)"
echo ""
echo "=== 上传到GitHub ==="
echo "1. 访问 https://github.com/new"
echo "2. 创建新仓库: wechat-ai-assistant"
echo "3. 不要初始化README、.gitignore、LICENSE"
echo "4. 创建后，点击'Add file' → 'Upload files'"
echo "5. 拖拽 wechat-ai-assistant.zip 到上传区域"
echo "6. GitHub会自动解压zip文件"
echo "7. 点击'Commit changes'"
echo ""
echo "=== 网页上传步骤 ==="
echo "📱 手机用户:"
echo "  1. 在文件管理器中找到 wechat-ai-assistant.zip"
echo "  2. 通过浏览器访问GitHub"
echo "  3. 在仓库页面点击'Add file' → 'Upload files'"
echo "  4. 选择'选择文件'，找到zip文件"
echo "  5. 上传并提交"
echo ""
echo "💻 电脑用户:"
echo "  1. 将zip文件传输到电脑"
echo "  2. 在GitHub网页上传"
echo ""
echo "=== 验证上传 ==="
echo "上传后检查以下文件是否存在:"
echo "  ✓ .github/workflows/android-build.yml"
echo "  ✓ app/build.gradle"
echo "  ✓ app/src/main/AndroidManifest.xml"
echo "  ✓ build.gradle"
echo "  ✓ gradlew"
echo ""
echo "=== 触发编译 ==="
echo "1. 进入仓库的'Actions'标签页"
echo "2. 点击'Android Build'工作流"
echo "3. 点击'Run workflow' → 'Run workflow'"
echo "4. 等待编译完成（约2-5分钟）"
echo "5. 在Artifacts中下载APK"
echo ""
echo "⚠️ 注意: 首次编译可能需要几分钟下载依赖"
echo "📦 生成的APK位于: app/build/outputs/apk/debug/"