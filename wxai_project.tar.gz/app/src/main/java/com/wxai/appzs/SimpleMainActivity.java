package com.wxai.appzs;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

/**
 * 简化版主Activity，用于测试编译
 */
public class SimpleMainActivity extends AppCompatActivity {
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        TextView textView = new TextView(this);
        textView.setText("微信AI助手 - 简化测试版\n\n如果看到这个，说明基本编译成功。\n\n完整功能需要Xposed框架支持。");
        textView.setPadding(50, 50, 50, 50);
        textView.setTextSize(18);
        setContentView(textView);
    }
}
