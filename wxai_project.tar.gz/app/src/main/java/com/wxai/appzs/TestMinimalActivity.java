package com.wxai.appzs;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

/**
 * 极简测试Activity - 只包含最基本功能
 */
public class TestMinimalActivity extends AppCompatActivity {
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        TextView textView = new TextView(this);
        textView.setText("极简测试 - 编译成功！");
        textView.setTextSize(24);
        setContentView(textView);
    }
}