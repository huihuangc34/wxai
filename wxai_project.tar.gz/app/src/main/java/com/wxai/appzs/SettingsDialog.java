package com.wxai.appzs;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

public class SettingsDialog extends AlertDialog {
    
    private OnSettingsSavedListener listener;
    
    private EditText apiKeyEditText;
    private EditText apiUrlEditText;
    private EditText modelNameEditText;
    private EditText temperatureEditText;
    private EditText maxTokensEditText;
    private EditText maxHistoryRoundsEditText;
    private CheckBox enableQuoteReplyCheckBox;
    private CheckBox enableSystemPromptCheckBox;
    private Button saveButton;
    private Button cancelButton;
    
    private SharedPreferences preferences;
    
    public SettingsDialog(Context context) {
        super(context);
        this.preferences = context.getSharedPreferences("wechat_ai_config", Context.MODE_PRIVATE);
    }
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_settings);
        
        initViews();
        loadSettings();
        setupListeners();
    }
    
    private void initViews() {
        apiKeyEditText = findViewById(R.id.apiKeyEditText);
        apiUrlEditText = findViewById(R.id.apiUrlEditText);
        modelNameEditText = findViewById(R.id.modelNameEditText);
        temperatureEditText = findViewById(R.id.temperatureEditText);
        maxTokensEditText = findViewById(R.id.maxTokensEditText);
        maxHistoryRoundsEditText = findViewById(R.id.maxHistoryRoundsEditText);
        enableQuoteReplyCheckBox = findViewById(R.id.enableQuoteReplyCheckBox);
        enableSystemPromptCheckBox = findViewById(R.id.enableSystemPromptCheckBox);
        saveButton = findViewById(R.id.saveButton);
        cancelButton = findViewById(R.id.cancelButton);
    }
    
    private void loadSettings() {
        apiKeyEditText.setText(preferences.getString("api_key", ""));
        apiUrlEditText.setText(preferences.getString("api_url", "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions"));
        modelNameEditText.setText(preferences.getString("model_name", "qwen-turbo"));
        temperatureEditText.setText(preferences.getString("temperature", "0.5"));
        maxTokensEditText.setText(preferences.getString("max_tokens", "1024"));
        maxHistoryRoundsEditText.setText(preferences.getString("max_history_rounds", "10"));
        enableQuoteReplyCheckBox.setChecked(preferences.getBoolean("enable_quote_reply", false));
        enableSystemPromptCheckBox.setChecked(preferences.getBoolean("enable_system_prompt", true));
    }
    
    private void setupListeners() {
        saveButton.setOnClickListener(v -> saveSettings());
        cancelButton.setOnClickListener(v -> dismiss());
    }
    
    private void saveSettings() {
        SharedPreferences.Editor editor = preferences.edit();
        
        String apiKey = apiKeyEditText.getText().toString().trim();
        if (apiKey.isEmpty()) {
            Toast.makeText(getContext(), "API Key不能为空", Toast.LENGTH_SHORT).show();
            return;
        }
        
        editor.putString("api_key", apiKey);
        editor.putString("api_url", apiUrlEditText.getText().toString().trim());
        editor.putString("model_name", modelNameEditText.getText().toString().trim());
        
        try {
            double temperature = Double.parseDouble(temperatureEditText.getText().toString());
            editor.putString("temperature", String.valueOf(Math.max(0.0, Math.min(temperature, 1.0))));
        } catch (NumberFormatException e) {
            editor.putString("temperature", "0.5");
        }
        
        try {
            int maxTokens = Integer.parseInt(maxTokensEditText.getText().toString());
            editor.putString("max_tokens", String.valueOf(Math.max(100, Math.min(maxTokens, 4096))));
        } catch (NumberFormatException e) {
            editor.putString("max_tokens", "1024");
        }
        
        try {
            int maxHistoryRounds = Integer.parseInt(maxHistoryRoundsEditText.getText().toString());
            editor.putString("max_history_rounds", String.valueOf(Math.max(1, Math.min(maxHistoryRounds, 50))));
        } catch (NumberFormatException e) {
            editor.putString("max_history_rounds", "10");
        }
        
        editor.putBoolean("enable_quote_reply", enableQuoteReplyCheckBox.isChecked());
        editor.putBoolean("enable_system_prompt", enableSystemPromptCheckBox.isChecked());
        
        editor.apply();
        
        if (listener != null) {
            listener.onSettingsSaved();
        }
        
        Toast.makeText(getContext(), "设置已保存", Toast.LENGTH_SHORT).show();
        dismiss();
    }
    
    public void setOnSettingsSavedListener(OnSettingsSavedListener listener) {
        this.listener = listener;
    }
    
    public interface OnSettingsSavedListener {
        void onSettingsSaved();
    }
}