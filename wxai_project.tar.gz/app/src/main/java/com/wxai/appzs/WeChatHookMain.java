package com.wxai.appzs;

import android.app.AndroidAppHelper;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.wxai.appzs.BuildConfig;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

public class WeChatHookMain implements IXposedHookLoadPackage {
    
    private static final String TAG = "WeChatAI";
    private static final String WECHAT_PACKAGE = "com.tencent.mm";
    
    // 好友列表缓存
    private static List<Map<String, String>> friendList = new ArrayList<>();
    private static Map<String, FriendConfig> friendConfigs = new ConcurrentHashMap<>();
    private static Handler mainHandler = new Handler(Looper.getMainLooper());
    
    @Override
    public void handleLoadPackage(LoadPackageParam lpparam) throws Throwable {
        // Hook自己的应用，修改isModuleActivated返回值
        if (BuildConfig.APPLICATION_ID.equals(lpparam.packageName)) {
            XposedHelpers.findAndHookMethod(
                MainActivity.class.getName(),
                lpparam.classLoader,
                "isModuleActivated",
                XC_MethodHook.MethodReplacement.returnConstant(true));
            return;
        }
        
        // 只Hook微信
        if (!WECHAT_PACKAGE.equals(lpparam.packageName)) {
            return;
        }
        
        Log.d(TAG, "开始Hook微信...");
        
        // 初始化配置
        loadFriendConfigs();
        
        // Hook微信的启动
        hookWeChatLaunch(lpparam);
        
        // Hook联系人相关方法
        hookContactMethods(lpparam);
        
        // Hook聊天相关方法
        hookChatMethods(lpparam);
        
        // Hook消息接收
        hookMessageReceive(lpparam);
        
        Log.d(TAG, "微信Hook完成");
    }
    
    private void hookWeChatLaunch(LoadPackageParam lpparam) {
        try {
            // Hook微信的LauncherUI（主界面）
            Class<?> launcherUIClass = XposedHelpers.findClassIfExists(
                "com.tencent.mm.ui.LauncherUI", 
                lpparam.classLoader);
            
            if (launcherUIClass != null) {
                XposedHelpers.findAndHookMethod(launcherUIClass, "onCreate", 
                    Bundle.class, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        Log.d(TAG, "微信主界面已启动");
                        Context context = (Context) param.thisObject;
                        
                        // 在主线程中显示提示
                        mainHandler.post(() -> {
                            Toast.makeText(context, "微信AI助手已激活", Toast.LENGTH_SHORT).show();
                        });
                        
                        // 启动时获取好友列表
                        new Thread(() -> {
                            try {
                                Thread.sleep(3000); // 等待微信初始化完成
                                fetchFriendList(lpparam.classLoader);
                                saveFriendListToCache(context);
                            } catch (Exception e) {
                                Log.e(TAG, "获取好友列表失败: " + e.getMessage());
                            }
                        }).start();
                    }
                });
            }
        } catch (Exception e) {
            Log.e(TAG, "Hook微信启动失败: " + e.getMessage());
        }
    }
    
    private void hookContactMethods(LoadPackageParam lpparam) {
        try {
            // Hook联系人管理器
            Class<?> contactStorageClass = XposedHelpers.findClassIfExists(
                "com.tencent.mm.storage.af", // 联系人存储类
                lpparam.classLoader);
            
            if (contactStorageClass != null) {
                // Hook获取所有联系人的方法
                Method getAllMethod = XposedHelpers.findMethodBestMatch(
                    contactStorageClass, 
                    "getAll", 
                    String.class); // 通常是getAll(String where)
                
                if (getAllMethod != null) {
                    XposedBridge.hookMethod(getAllMethod, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            Object result = param.getResult();
                            if (result != null) {
                                // 解析联系人列表
                                parseContactList(result);
                            }
                        }
                    });
                }
            }
            
            // Hook联系人信息类
            Class<?> contactInfoClass = XposedHelpers.findClassIfExists(
                "com.tencent.mm.storage.s", // 联系人信息类
                lpparam.classLoader);
            
            if (contactInfoClass != null) {
                // Hook获取字段的方法
                XposedHelpers.findAndHookMethod(contactInfoClass, "field_getUsername", 
                    new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        // 可以在这里记录联系人信息
                    }
                });
                
                XposedHelpers.findAndHookMethod(contactInfoClass, "field_getNickname", 
                    new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        // 可以在这里记录联系人昵称
                    }
                });
                
                XposedHelpers.findAndHookMethod(contactInfoClass, "field_getConRemark", 
                    new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        // 可以在这里记录联系人备注
                    }
                });
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Hook联系人方法失败: " + e.getMessage());
        }
    }
    
    private void hookChatMethods(LoadPackageParam lpparam) {
        try {
            // Hook聊天界面
            Class<?> chatUIFieldClass = XposedHelpers.findClassIfExists(
                "com.tencent.mm.ui.chatting.ChattingUI", 
                lpparam.classLoader);
            
            if (chatUIFieldClass != null) {
                // Hook聊天界面的onCreate方法
                XposedHelpers.findAndHookMethod(chatUIFieldClass, "onCreate", 
                    Bundle.class, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        Log.d(TAG, "进入聊天界面");
                        
                        // 获取聊天对象
                        Object chatUI = param.thisObject;
                        String talker = (String) XposedHelpers.getObjectField(chatUI, "field_talker");
                        
                        if (talker != null) {
                            Log.d(TAG, "正在与 " + talker + " 聊天");
                            
                            // 检查是否有配置
                            FriendConfig config = friendConfigs.get(talker);
                            if (config != null && config.enableAI) {
                                Log.d(TAG, "为 " + talker + " 启用AI回复");
                                
                                // 可以在聊天界面添加AI开关按钮
                                addAISwitchToChatUI(chatUI, talker, config);
                            }
                        }
                    }
                });
            }
        } catch (Exception e) {
            Log.e(TAG, "Hook聊天方法失败: " + e.getMessage());
        }
    }
    
    private void hookMessageReceive(LoadPackageParam lpparam) {
        try {
            // Hook消息接收器
            Class<?> msgServiceClass = XposedHelpers.findClassIfExists(
                "com.tencent.mm.modelmulti.h", // 消息服务类
                lpparam.classLoader);
            
            if (msgServiceClass != null) {
                // Hook处理新消息的方法
                XposedHelpers.findAndHookMethod(msgServiceClass, "a", 
                    int.class, Object.class, Object.class, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        // 这里可以处理新消息
                        // 微信的消息处理比较复杂，需要更深入的分析
                        Log.d(TAG, "收到新消息");
                    }
                });
            }
            
            // Hook消息存储
            Class<?> msgStorageClass = XposedHelpers.findClassIfExists(
                "com.tencent.mm.storage.au", // 消息存储类
                lpparam.classLoader);
            
            if (msgStorageClass != null) {
                // Hook插入消息的方法
                XposedHelpers.findAndHookMethod(msgStorageClass, "a", 
                    msgStorageClass, boolean.class, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        Object msgObj = param.args[0];
                        if (msgObj != null) {
                            // 解析消息内容
                            String talker = (String) XposedHelpers.callMethod(msgObj, "field_talker");
                            String content = (String) XposedHelpers.callMethod(msgObj, "field_content");
                            int type = (int) XposedHelpers.callMethod(msgObj, "field_type");
                            
                            if (type == 1) { // 文本消息
                                Log.d(TAG, "收到文本消息: " + talker + " -> " + content);
                                
                                // 检查是否需要AI回复
                                checkAndReplyAI(talker, content, msgObj, lpparam.classLoader);
                            }
                        }
                    }
                });
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Hook消息接收失败: " + e.getMessage());
        }
    }
    
    private void checkAndReplyAI(String talker, String content, Object msgObj, ClassLoader classLoader) {
        FriendConfig config = friendConfigs.get(talker);
        if (config == null || !config.enableAI) {
            return;
        }
        
        // 检查关键词过滤
        if (config.keywords != null && !config.keywords.isEmpty()) {
            boolean hasKeyword = false;
            for (String keyword : config.keywords.split(",")) {
                if (content.contains(keyword.trim())) {
                    hasKeyword = true;
                    break;
                }
            }
            if (!hasKeyword) {
                return; // 不包含关键词，不回复
            }
        }
        
        Log.d(TAG, "准备为 " + talker + " 发送AI回复");
        
        // 延迟回复
        mainHandler.postDelayed(() -> {
            try {
                // 调用AI接口获取回复
                String aiReply = getAIResponse(content, config.aiPrompt);
                if (aiReply != null && !aiReply.isEmpty()) {
                    // 发送回复消息
                    sendTextMessage(talker, aiReply, classLoader);
                    Log.d(TAG, "AI回复已发送: " + aiReply);
                }
            } catch (Exception e) {
                Log.e(TAG, "AI回复失败: " + e.getMessage());
            }
        }, config.responseDelay * 1000L);
    }
    
    private String getAIResponse(String content, String prompt) {
        // 这里应该调用AI接口
        // 为了简化，这里返回一个简单的回复
        return "嗯，你说的这个" + content.substring(0, Math.min(10, content.length())) + "...确实有点意思";
    }
    
    private void sendTextMessage(String talker, String content, ClassLoader classLoader) {
        try {
            // 获取聊天UI类
            Class<?> chatUIFieldClass = XposedHelpers.findClassIfExists(
                "com.tencent.mm.ui.chatting.ChattingUI", 
                classLoader);
            
            if (chatUIFieldClass != null) {
                // 获取当前活动的聊天界面
                // 这里需要更复杂的逻辑来找到正确的聊天界面实例
            }
            
            // 或者直接通过微信的消息发送接口发送
            Class<?> msgLogicClass = XposedHelpers.findClassIfExists(
                "com.tencent.mm.model.bd", // 消息逻辑类
                classLoader);
            
            if (msgLogicClass != null) {
                Object msgLogic = XposedHelpers.callStaticMethod(msgLogicClass, "a");
                if (msgLogic != null) {
                    // 创建消息对象
                    Class<?> msgInfoClass = XposedHelpers.findClassIfExists(
                        "com.tencent.mm.storage.au", 
                        classLoader);
                    
                    if (msgInfoClass != null) {
                        Object msgObj = XposedHelpers.newInstance(msgInfoClass);
                        XposedHelpers.callMethod(msgObj, "setType", 1); // 文本消息
                        XposedHelpers.callMethod(msgObj, "setTalker", talker);
                        XposedHelpers.callMethod(msgObj, "setContent", content);
                        
                        // 发送消息
                        XposedHelpers.callMethod(msgLogic, "a", msgObj, 0);
                    }
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "发送消息失败: " + e.getMessage());
        }
    }
    
    private void parseContactList(Object contactList) {
        friendList.clear();
        
        try {
            if (contactList instanceof List) {
                List<?> list = (List<?>) contactList;
                for (Object contact : list) {
                    Map<String, String> friend = new HashMap<>();
                    
                    // 获取微信ID
                    String wxid = (String) XposedHelpers.callMethod(contact, "field_getUsername");
                    if (wxid == null || wxid.isEmpty()) {
                        continue;
                    }
                    
                    // 获取昵称
                    String nickname = (String) XposedHelpers.callMethod(contact, "field_getNickname");
                    
                    // 获取备注
                    String remark = (String) XposedHelpers.callMethod(contact, "field_getConRemark");
                    
                    friend.put("wxid", wxid);
                    friend.put("nickname", nickname != null ? nickname : "");
                    friend.put("remark", remark != null ? remark : "");
                    
                    friendList.add(friend);
                }
                
                Log.d(TAG, "解析到 " + friendList.size() + " 个好友");
            }
        } catch (Exception e) {
            Log.e(TAG, "解析联系人列表失败: " + e.getMessage());
        }
    }
    
    private void fetchFriendList(ClassLoader classLoader) {
        try {
            // 通过反射调用微信的获取好友列表方法
            Class<?> contactStorageClass = XposedHelpers.findClassIfExists(
                "com.tencent.mm.storage.af", 
                classLoader);
            
            if (contactStorageClass != null) {
                // 获取联系人管理器实例
                Object contactStorage = XposedHelpers.callStaticMethod(
                    contactStorageClass, "a", classLoader);
                
                if (contactStorage != null) {
                    // 调用获取所有联系人的方法
                    Object contactList = XposedHelpers.callMethod(
                        contactStorage, "getAll", "");
                    
                    parseContactList(contactList);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "获取好友列表失败: " + e.getMessage());
        }
    }
    
    private void saveFriendListToCache(Context context) {
        try {
            JSONArray jsonArray = new JSONArray();
            for (Map<String, String> friend : friendList) {
                JSONObject obj = new JSONObject();
                obj.put("wxid", friend.get("wxid"));
                obj.put("nickname", friend.get("nickname"));
                obj.put("remark", friend.get("remark"));
                jsonArray.put(obj);
            }
            
            // 保存到SharedPreferences
            SharedPreferences prefs = context.getSharedPreferences("wechat_ai_cache", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putString("friend_list_cache", jsonArray.toString());
            editor.apply();
            
            // 保存到文件
            File cacheFile = new File(context.getExternalFilesDir(null), "wechat_friends.json");
            FileOutputStream fos = new FileOutputStream(cacheFile);
            fos.write(jsonArray.toString().getBytes("UTF-8"));
            fos.close();
            
            Log.d(TAG, "好友列表已保存到缓存: " + friendList.size() + " 个好友");
        } catch (Exception e) {
            Log.e(TAG, "保存好友列表失败: " + e.getMessage());
        }
    }
    
    private void loadFriendConfigs() {
        // 这里应该从配置文件加载好友配置
        // 为了简化，这里创建一些示例配置
        friendConfigs.clear();
        
        // 示例配置
        FriendConfig config1 = new FriendConfig();
        config1.wxid = "wxid_example1";
        config1.enableAI = true;
        config1.aiPrompt = "你是一个普通的中国年轻人，正在用微信和朋友闲聊。";
        config1.responseDelay = 3;
        config1.keywords = "帮忙,问题,怎么";
        config1.autoReply = "稍等，正在忙";
        friendConfigs.put(config1.wxid, config1);
        
        FriendConfig config2 = new FriendConfig();
        config2.wxid = "wxid_example2";
        config2.enableAI = false;
        config2.autoReply = "我现在不方便，稍后回复你";
        friendConfigs.put(config2.wxid, config2);
    }
    
    private void addAISwitchToChatUI(Object chatUI, String talker, FriendConfig config) {
        // 这里可以在聊天界面添加AI开关
        // 实现较复杂，需要动态修改UI
    }
    
    static class FriendConfig {
        String wxid;
        boolean enableAI;
        String aiPrompt;
        int responseDelay;
        String keywords;
        String autoReply;
        boolean enableLog;
    }
}