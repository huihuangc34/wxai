package com.wxai.appzs;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private ListView friendListView;
    private TextView statusTextView;
    private Button btnRefresh, btnExport, btnImport, btnSettings;
    private List<FriendInfo> friendList = new ArrayList<>();
    private FriendAdapter adapter;
    private SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // 初始化视图
        friendListView = findViewById(R.id.friendListView);
        statusTextView = findViewById(R.id.statusTextView);
        btnRefresh = findViewById(R.id.btnRefresh);
        btnExport = findViewById(R.id.btnExport);
        btnImport = findViewById(R.id.btnImport);
        btnSettings = findViewById(R.id.btnSettings);
        
        preferences = getSharedPreferences("wechat_ai_config", MODE_PRIVATE);
        
        // 设置状态
        statusTextView.setText(isModuleActivated() ? 
            getString(R.string.xposed_activated) : 
            getString(R.string.xposed_unactivated));
        
        // 设置按钮点击事件
        btnRefresh.setOnClickListener(v -> refreshFriendList());
        btnExport.setOnClickListener(v -> exportConfig());
        btnImport.setOnClickListener(v -> importConfig());
        btnSettings.setOnClickListener(v -> openSettings());
        
        // 设置列表点击事件
        friendListView.setOnItemClickListener((parent, view, position, id) -> {
            FriendInfo friend = friendList.get(position);
            showFriendConfigDialog(friend);
        });
        
        // 初始化适配器
        adapter = new FriendAdapter(this, friendList);
        friendListView.setAdapter(adapter);
        
        // 加载好友列表
        loadFriendList();
    }
    
    private void refreshFriendList() {
        // 这里应该从Hook模块获取好友列表
        // 目前先加载本地保存的
        loadFriendList();
        Toast.makeText(this, getString(R.string.toast_friend_list_updated), Toast.LENGTH_SHORT).show();
    }
    
    private void loadFriendList() {
        friendList.clear();
        
        // 尝试从Hook模块获取好友列表
        String friendData = getFriendListFromHook();
        if (friendData != null && !friendData.isEmpty()) {
            try {
                JSONArray jsonArray = new JSONArray(friendData);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject obj = jsonArray.getJSONObject(i);
                    FriendInfo friend = new FriendInfo();
                    friend.wxid = obj.optString("wxid", "");
                    friend.nickname = obj.optString("nickname", "");
                    friend.remark = obj.optString("remark", "");
                    friendList.add(friend);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        
        // 如果没有从Hook获取到，尝试从配置文件加载
        if (friendList.isEmpty()) {
            loadFriendsFromConfig();
        }
        
        // 按昵称排序
        Collections.sort(friendList, (f1, f2) -> {
            String name1 = f1.getDisplayName();
            String name2 = f2.getDisplayName();
            return name1.compareToIgnoreCase(name2);
        });
        
        adapter.notifyDataSetChanged();
        statusTextView.setText(String.format("已加载 %d 个好友", friendList.size()));
    }
    
    private String getFriendListFromHook() {
        // 这里应该通过某种方式从Hook模块获取好友列表
        // 例如通过SharedPreferences、文件或广播
        return preferences.getString("friend_list_cache", "");
    }
    
    private void loadFriendsFromConfig() {
        try {
            File configFile = new File(getExternalFilesDir(null), getString(R.string.friend_list_file));
            if (configFile.exists()) {
                FileInputStream fis = new FileInputStream(configFile);
                byte[] data = new byte[(int) configFile.length()];
                fis.read(data);
                fis.close();
                
                String json = new String(data, "UTF-8");
                JSONArray jsonArray = new JSONArray(json);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject obj = jsonArray.getJSONObject(i);
                    FriendInfo friend = new FriendInfo();
                    friend.wxid = obj.optString("wxid", "");
                    friend.nickname = obj.optString("nickname", "");
                    friend.remark = obj.optString("remark", "");
                    friendList.add(friend);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void showFriendConfigDialog(FriendInfo friend) {
        FriendConfigDialog dialog = new FriendConfigDialog(this, friend);
        dialog.setOnConfigSavedListener((configFriend, config) -> {
            saveFriendConfig(configFriend, config);
            Toast.makeText(this, getString(R.string.toast_config_saved), Toast.LENGTH_SHORT).show();
        });
        dialog.show();
    }
    
    private void saveFriendConfig(FriendInfo friend, JSONObject config) {
        try {
            // 保存到SharedPreferences
            SharedPreferences.Editor editor = preferences.edit();
            editor.putString("config_" + friend.wxid, config.toString());
            editor.apply();
            
            // 保存到文件
            saveConfigToFile();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void saveConfigToFile() {
        try {
            JSONObject allConfig = new JSONObject();
            Map<String, ?> allPrefs = preferences.getAll();
            
            for (Map.Entry<String, ?> entry : allPrefs.entrySet()) {
                if (entry.getKey().startsWith("config_")) {
                    allConfig.put(entry.getKey(), entry.getValue());
                }
            }
            
            File configFile = new File(getExternalFilesDir(null), getString(R.string.config_file_name));
            FileOutputStream fos = new FileOutputStream(configFile);
            fos.write(allConfig.toString().getBytes("UTF-8"));
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void exportConfig() {
        try {
            File exportDir = new File(getExternalFilesDir(null), "export");
            if (!exportDir.exists()) {
                exportDir.mkdirs();
            }
            
            File exportFile = new File(exportDir, "wechat_ai_config_export.json");
            FileOutputStream fos = new FileOutputStream(exportFile);
            
            JSONObject exportData = new JSONObject();
            exportData.put("version", "1.0");
            exportData.put("export_time", System.currentTimeMillis());
            
            // 好友配置
            JSONObject configs = new JSONObject();
            Map<String, ?> allPrefs = preferences.getAll();
            for (Map.Entry<String, ?> entry : allPrefs.entrySet()) {
                if (entry.getKey().startsWith("config_")) {
                    configs.put(entry.getKey(), entry.getValue());
                }
            }
            exportData.put("configs", configs);
            
            // 好友列表
            JSONArray friendsArray = new JSONArray();
            for (FriendInfo friend : friendList) {
                JSONObject friendObj = new JSONObject();
                friendObj.put("wxid", friend.wxid);
                friendObj.put("nickname", friend.nickname);
                friendObj.put("remark", friend.remark);
                friendsArray.put(friendObj);
            }
            exportData.put("friends", friendsArray);
            
            fos.write(exportData.toString(2).getBytes("UTF-8"));
            fos.close();
            
            Toast.makeText(this, getString(R.string.toast_export_success) + ": " + exportFile.getAbsolutePath(), 
                Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "导出失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    
    private void importConfig() {
        // 这里应该实现导入逻辑
        // 暂时简单地从文件恢复
        try {
            File configFile = new File(getExternalFilesDir(null), getString(R.string.config_file_name));
            if (configFile.exists()) {
                FileInputStream fis = new FileInputStream(configFile);
                byte[] data = new byte[(int) configFile.length()];
                fis.read(data);
                fis.close();
                
                String json = new String(data, "UTF-8");
                JSONObject configObj = new JSONObject(json);
                
                SharedPreferences.Editor editor = preferences.edit();
                Iterator<String> keys = configObj.keys();
                while (keys.hasNext()) {
                    String key = keys.next();
                    String value = configObj.getString(key);
                    editor.putString(key, value);
                }
                editor.apply();
                
                Toast.makeText(this, getString(R.string.toast_import_success), Toast.LENGTH_SHORT).show();
                loadFriendList();
            } else {
                Toast.makeText(this, "未找到配置文件", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "导入失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    
    private void openSettings() {
        SettingsDialog dialog = new SettingsDialog(this);
        dialog.setOnSettingsSavedListener(() -> {
            Toast.makeText(this, "设置已保存", Toast.LENGTH_SHORT).show();
        });
        dialog.show();
    }
    
    public static boolean isModuleActivated() {
        // 这个值会在Hook模块中被修改
        return false;
    }
    
    static class FriendInfo {
        String wxid;
        String nickname;
        String remark;
        
        String getDisplayName() {
            if (remark != null && !remark.isEmpty()) {
                return remark;
            }
            return nickname != null ? nickname : wxid;
        }
    }
}