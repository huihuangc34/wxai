package com.wxai.appzs;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class FriendAdapter extends BaseAdapter {
    
    private Context context;
    private List<MainActivity.FriendInfo> friendList;
    private LayoutInflater inflater;
    
    public FriendAdapter(Context context, List<MainActivity.FriendInfo> friendList) {
        this.context = context;
        this.friendList = friendList;
        this.inflater = LayoutInflater.from(context);
    }
    
    @Override
    public int getCount() {
        return friendList.size();
    }
    
    @Override
    public Object getItem(int position) {
        return friendList.get(position);
    }
    
    @Override
    public long getItemId(int position) {
        return position;
    }
    
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_friend, parent, false);
            holder = new ViewHolder();
            holder.avatarImageView = convertView.findViewById(R.id.avatarImageView);
            holder.nameTextView = convertView.findViewById(R.id.nameTextView);
            holder.wxidTextView = convertView.findViewById(R.id.wxidTextView);
            holder.aiStatusView = convertView.findViewById(R.id.aiStatusView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        
        MainActivity.FriendInfo friend = friendList.get(position);
        
        // 设置头像（默认头像）
        holder.avatarImageView.setImageResource(R.drawable.ic_friend_avatar);
        
        // 设置名称
        holder.nameTextView.setText(friend.getDisplayName());
        
        // 设置微信ID
        holder.wxidTextView.setText(friend.wxid);
        
        // 设置AI状态
        // 这里应该检查该好友是否启用了AI回复
        // 暂时显示默认状态
        holder.aiStatusView.setVisibility(View.VISIBLE);
        
        return convertView;
    }
    
    static class ViewHolder {
        ImageView avatarImageView;
        TextView nameTextView;
        TextView wxidTextView;
        View aiStatusView;
    }
}