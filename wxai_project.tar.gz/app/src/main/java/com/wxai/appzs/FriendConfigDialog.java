package com.wxai.appzs;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import org.json.JSONException;
import org.json.JSONObject;

public class FriendConfigDialog extends AlertDialog {
    
    private MainActivity.FriendInfo friend;
    private OnConfigSavedListener listener;
    
    private TextView titleTextView;
    private EditText aiPromptEditText;
    private EditText responseDelayEditText;
    private EditText keywordsEditText;
    private EditText autoReplyEditText;
    private CheckBox enableAICheckBox;
    private CheckBox enableLogCheckBox;
    private Button saveButton;
    private Button cancelButton;
    
    private SharedPreferences preferences;
    
    public FriendConfigDialog(Context context, MainActivity.FriendInfo friend) {
        super(context);
        this.friend = friend;
        this.preferences = context.getSharedPreferences("wechat_ai_config", Context.MODE_PRIVATE);
    }
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_friend_config);
        
        initViews();
        loadConfig();
        setupListeners();
    }
    
    private void initViews() {
        titleTextView = findViewById(R.id.titleTextView);
        aiPromptEditText = findViewById(R.id.aiPromptEditText);
        responseDelayEditText = findViewById(R.id.responseDelayEditText);
        keywordsEditText = findViewById(R.id.keywordsEditText);
        autoReplyEditText = findViewById(R.id.autoReplyEditText);
        enableAICheckBox = findViewById(R.id.enableAICheckBox);
        enableLogCheckBox = findViewById(R.id.enableLogCheckBox);
        saveButton = findViewById(R.id.saveButton);
        cancelButton = findViewById(R.id.cancelButton);
        
        titleTextView.setText("配置好友: " + friend.getDisplayName());
    }
    
    private void loadConfig() {
        String configJson = preferences.getString("config_" + friend.wxid, "");
        
        if (!configJson.isEmpty()) {
            try {
                JSONObject config = new JSONObject(configJson);
                
                enableAICheckBox.setChecked(config.optBoolean("enableAI", false));
                aiPromptEditText.setText(config.optString("aiPrompt", 
                    getContext().getString(R.string.default_ai_prompt)));
                responseDelayEditText.setText(String.valueOf(config.optInt("responseDelay", 3)));
                keywordsEditText.setText(config.optString("keywords", 
                    getContext().getString(R.string.default_keywords)));
                autoReplyEditText.setText(config.optString("autoReply", 
                    getContext().getString(R.string.default_auto_reply)));
                enableLogCheckBox.setChecked(config.optBoolean("enableLog", false));
                
            } catch (JSONException e) {
                e.printStackTrace();
            }
        } else {
            // 使用默认值
            aiPromptEditText.setText(getContext().getString(R.string.default_ai_prompt));
            responseDelayEditText.setText("3");
            keywordsEditText.setText(getContext().getString(R.string.default_keywords));
            autoReplyEditText.setText(getContext().getString(R.string.default_auto_reply));
        }
    }
    
    private void setupListeners() {
        saveButton.setOnClickListener(v -> saveConfig());
        cancelButton.setOnClickListener(v -> dismiss());
        
        // AI开关变化时，控制相关字段的可用性
        enableAICheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            aiPromptEditText.setEnabled(isChecked);
            responseDelayEditText.setEnabled(isChecked);
            keywordsEditText.setEnabled(isChecked);
        });
        
        // 初始状态
        boolean aiEnabled = enableAICheckBox.isChecked();
        aiPromptEditText.setEnabled(aiEnabled);
        responseDelayEditText.setEnabled(aiEnabled);
        keywordsEditText.setEnabled(aiEnabled);
    }
    
    private void saveConfig() {
        try {
            JSONObject config = new JSONObject();
            
            config.put("wxid", friend.wxid);
            config.put("nickname", friend.nickname);
            config.put("remark", friend.remark);
            config.put("enableAI", enableAICheckBox.isChecked());
            config.put("aiPrompt", aiPromptEditText.getText().toString().trim());
            
            try {
                int delay = Integer.parseInt(responseDelayEditText.getText().toString());
                config.put("responseDelay", Math.max(0, Math.min(delay, 60))); // 限制0-60秒
            } catch (NumberFormatException e) {
                config.put("responseDelay", 3);
            }
            
            config.put("keywords", keywordsEditText.getText().toString().trim());
            config.put("autoReply", autoReplyEditText.getText().toString().trim());
            config.put("enableLog", enableLogCheckBox.isChecked());
            
            if (listener != null) {
                listener.onConfigSaved(friend, config);
            }
            
            dismiss();
            
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(getContext(), "保存失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    
    public void setOnConfigSavedListener(OnConfigSavedListener listener) {
        this.listener = listener;
    }
    
    public interface OnConfigSavedListener {
        void onConfigSaved(MainActivity.FriendInfo friend, JSONObject config);
    }
}