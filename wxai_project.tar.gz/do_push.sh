#!/bin/bash
echo "开始推送到GitHub..."
echo "当前目录: $(pwd)"

# 检查Git状态
git status

# 添加所有文件
echo "添加所有文件..."
git add .

# 提交更改
echo "提交更改..."
git commit -m "推送微信AI助手项目 $(date +'%Y-%m-%d %H:%M:%S')"

# 推送到GitHub
echo "推送到GitHub..."
git push origin master

if [ $? -eq 0 ]; then
    echo "✅ 推送成功！"
    echo "请访问: https://github.com/huihuangc34/wxai"
else
    echo "❌ 推送失败，尝试强制推送..."
    git push --force origin master
fi

echo "完成！"