#!/bin/bash
# Git仓库初始化脚本
# 使用方法: 
# 1. 在Termux中安装git: pkg install git
# 2. 运行: bash git_init.sh

echo "=== 微信AI助手 Git仓库初始化 ==="
echo ""

# 检查是否在项目目录
if [ ! -f "build.gradle" ] || [ ! -d "app" ]; then
    echo "❌ 错误: 请在项目根目录运行此脚本"
    echo "项目根目录应包含: build.gradle, app/ 等文件"
    exit 1
fi

# 检查git是否安装
if ! command -v git &> /dev/null; then
    echo "⚠️  Git未安装"
    echo "在Termux中安装: pkg install git"
    echo "或在电脑上安装Git后再继续"
    exit 1
fi

echo "1. 初始化Git仓库..."
git init

echo "2. 添加所有文件..."
git add .

echo "3. 提交初始版本..."
git commit -m "Initial commit: 微信AI助手Xposed模块"

echo ""
echo "✅ Git仓库初始化完成！"
echo ""
echo "=== 下一步操作 ==="
echo ""
echo "A. 推送到GitHub新仓库:"
echo "   1. 访问 https://github.com/new 创建新仓库"
echo "   2. 获取仓库URL (如: https://github.com/用户名/仓库名.git)"
echo "   3. 运行以下命令:"
echo "      git remote add origin https://github.com/用户名/仓库名.git"
echo "      git branch -M main"
echo "      git push -u origin main"
echo ""
echo "B. 推送到GitHub现有仓库:"
echo "   1. 运行: git remote add origin 仓库URL"
echo "   2. 运行: git push -u origin main"
echo ""
echo "C. 使用GitHub Desktop或网页上传:"
echo "   1. 将整个项目文件夹压缩为zip"
echo "   2. 在GitHub仓库页面点击'Add file' → 'Upload files'"
echo "   3. 上传zip文件并解压"
echo ""
echo "=== GitHub云编译 ==="
echo "上传到GitHub后:"
echo "1. 进入仓库的'Actions'标签页"
echo "2. 选择'Android Build'工作流"
echo "3. 点击'Run workflow'手动触发"
echo "4. 等待编译完成，在Artifacts下载APK"
echo ""
echo "提示: 如果遇到权限问题，运行: chmod +x gradlew"