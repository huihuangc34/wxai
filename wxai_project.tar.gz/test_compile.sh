#!/system/bin/sh
echo "=== 微信AI助手编译测试 ==="
echo "当前目录: $(pwd)"
echo ""
echo "=== 1. 检查AndroidManifest.xml ==="
grep -n "MAIN\|LAUNCHER" app/src/main/AndroidManifest.xml
echo ""
echo "=== 2. 检查Java文件语法 ==="
find app/src -name "*.java" -exec echo "检查: {}" \; -exec grep -c "public class" {} \;
echo ""
echo "=== 3. 检查资源文件 ==="
echo "布局文件:"
find app/src -name "*.xml" | grep layout
echo ""
echo "=== 4. 检查依赖 ==="
echo "libs目录:"
ls -la app/libs/
echo ""
echo "=== 5. 检查BuildConfig引用 ==="
find app/src -name "*.java" -exec grep -l "BuildConfig" {} \;
echo ""
echo "=== 测试完成 ==="