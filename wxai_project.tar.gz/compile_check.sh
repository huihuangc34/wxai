#!/bin/bash
# 极简编译测试脚本
# 测试项目是否能通过基本语法检查

echo "=== 微信AI助手项目编译测试 ==="
echo ""

# 检查关键文件是否存在
echo "1. 检查项目结构..."
required_files=(
    "build.gradle"
    "app/build.gradle"
    "app/src/main/AndroidManifest.xml"
    "app/src/main/java/com/wxai/appzs/MainActivity.java"
    "app/src/main/res/values/strings.xml"
    "app/libs/compile_only/xposed-api-82_compileonly.jar"
)

missing_files=0
for file in "${required_files[@]}"; do
    if [ -f "$file" ] || [ -e "$file" ]; then
        echo "  ✓ $file"
    else
        echo "  ✗ $file (缺失)"
        missing_files=$((missing_files + 1))
    fi
done

if [ $missing_files -gt 0 ]; then
    echo "❌ 缺失 $missing_files 个必要文件"
    exit 1
fi

echo ""
echo "2. 检查Java语法..."
# 检查MainActivity是否有明显语法错误
if grep -q "class MainActivity extends AppCompatActivity" "app/src/main/java/com/wxai/appzs/MainActivity.java"; then
    echo "  ✓ MainActivity类定义正确"
else
    echo "  ✗ MainActivity类定义可能有问题"
fi

# 检查是否有未闭合的括号
if tail -1 "app/src/main/java/com/wxai/appzs/MainActivity.java" | grep -q "^[[:space:]]*}[[:space:]]*$"; then
    echo "  ✓ MainActivity文件结构完整"
else
    echo "  ✗ MainActivity可能缺少闭合括号"
fi

echo ""
echo "3. 检查AndroidManifest..."
# 检查包名
if grep -q 'package="com.wxai.appzs"' "app/src/main/AndroidManifest.xml"; then
    echo "  ✓ 包名正确"
else
    echo "  ✗ 包名可能错误"
fi

# 检查是否有重复的LAUNCHER Activity
launcher_count=$(grep -c "android.intent.category.LAUNCHER" "app/src/main/AndroidManifest.xml")
if [ "$launcher_count" -eq 1 ]; then
    echo "  ✓ 只有一个LAUNCHER Activity"
elif [ "$launcher_count" -eq 0 ]; then
    echo "  ⚠️ 没有LAUNCHER Activity"
else
    echo "  ✗ 有 $launcher_count 个LAUNCHER Activity（应该只有1个）"
fi

echo ""
echo "4. 检查build.gradle..."
# 检查编译版本
if grep -q "compileSdkVersion 33" "app/build.gradle"; then
    echo "  ✓ compileSdkVersion 33"
else
    echo "  ✗ compileSdkVersion不是33"
fi

if grep -q "targetSdkVersion 26" "app/build.gradle"; then
    echo "  ✓ targetSdkVersion 26"
else
    echo "  ✗ targetSdkVersion不是26"
fi

echo ""
echo "5. 检查依赖..."
# 检查Xposed API JAR是否存在
if [ -f "app/libs/compile_only/xposed-api-82_compileonly.jar" ]; then
    echo "  ✓ Xposed API JAR存在"
else
    echo "  ✗ Xposed API JAR缺失"
fi

# 检查AndroidX依赖
if grep -q "androidx.appcompat:appcompat" "app/build.gradle"; then
    echo "  ✓ AndroidX依赖存在"
else
    echo "  ✗ AndroidX依赖缺失"
fi

echo ""
echo "=== 测试结果 ==="
echo "项目基本结构检查完成。"
echo ""
echo "=== 下一步 ==="
echo "如果所有检查都通过 ✓，可以尝试："
echo "1. 运行 package_project.sh 打包项目"
echo "2. 上传到GitHub进行云编译"
echo "3. 或在AIDE Pro中尝试编译"
echo ""
echo "如果有 ✗ 标记的问题，请先修复这些问题。"
echo ""
echo "=== 快速修复建议 ==="
echo "1. 如果缺少Xposed API JAR："
echo "   从Xposed官网下载xposed-api-82.jar"
echo "   重命名为xposed-api-82_compileonly.jar"
echo "   放到 app/libs/compile_only/ 目录"
echo ""
echo "2. 如果有多个LAUNCHER Activity："
echo "   编辑AndroidManifest.xml"
echo "   只保留一个Activity有LAUNCHER intent-filter"
echo ""
echo "3. 如果build.gradle配置错误："
echo "   参考COMPILE_CHECK.md中的正确配置"