# 📦 微信AI助手 - 上传前检查清单

请按顺序完成以下步骤，确保项目能成功上传和编译。

## ✅ 第一步：项目完整性检查

### 1. 运行结构检查
```bash
sh compile_check.sh
```
**预期结果**：
- ✓ 所有必要文件存在
- ✓ 只有一个LAUNCHER Activity
- ✓ Xposed API JAR存在
- ✓ AndroidX依赖存在

### 2. 关键文件确认
打开文件管理器，检查以下文件：
- [ ] `app/libs/compile_only/xposed-api-82_compileonly.jar` 存在
- [ ] `app/src/main/AndroidManifest.xml` 没有语法错误
- [ ] `app/build.gradle` 配置正确
- [ ] `build.gradle` 配置正确

## ✅ 第二步：打包项目

### 1. 运行打包脚本
```bash
sh package_project.sh
```
**预期结果**：
- 在 `/storage/emulated/0/` 生成 `wechat-ai-assistant.zip`
- 大小约 100KB-1MB

### 2. 验证压缩包
- [ ] 压缩包存在
- [ ] 可以正常解压
- [ ] 包含所有必要文件

## ✅ 第三步：创建GitHub仓库

### 1. 访问GitHub
- 网址：https://github.com/new
- 登录你的GitHub账号

### 2. 创建仓库
- **仓库名**：`wechat-ai-assistant`（或自定义）
- **描述**：`微信AI助手Xposed模块`
- **公开/私有**：建议Public（公开）
- **初始化选项**：**不要**勾选任何选项
- **点击**：Create repository

## ✅ 第四步：上传文件

### 方法A：网页上传（推荐）
1. 在仓库页面点击"Add file" → "Upload files"
2. 拖拽 `wechat-ai-assistant.zip` 到上传区域
3. GitHub自动解压
4. 点击"Commit changes"

### 方法B：Git命令行
```bash
# 在Termux中
pkg install git
cd /storage/emulated/0/AideProjects/微信ai助手
sh git_init.sh
# 按照脚本提示操作
```

## ✅ 第五步：触发云编译

### 1. 进入Actions页面
- 仓库页面 → "Actions"标签页

### 2. 运行工作流
- 点击"Android Build"
- 点击"Run workflow" → "Run workflow"

### 3. 等待编译
- 等待约2-5分钟
- 观察进度条
- 查看日志输出

## ✅ 第六步：下载APK

### 1. 找到Artifacts
- 编译成功后，页面底部显示"Artifacts"
- 点击"debug-apk"

### 2. 下载安装
- 下载 `debug-apk.zip`
- 解压得到APK文件
- 安装到手机

## ✅ 第七步：测试模块

### 1. 安装APK
- 允许安装未知来源应用
- 安装微信AI助手

### 2. 配置LSPosed
- 打开LSPosed
- 模块列表中找到"微信AI助手"
- 勾选激活
- 作用域选择微信
- 重启微信

### 3. 测试功能
- 打开微信AI助手应用
- 配置API密钥（如果需要）
- 测试基本功能

## 🔧 故障排除

### 问题1：GitHub Actions失败
**症状**：红色×标记
**解决**：
1. 点击失败的运行
2. 查看"Build with Gradle"步骤的错误日志
3. 根据错误信息修复代码
4. 重新上传

### 问题2：APK无法安装
**症状**：安装失败
**解决**：
1. 检查Android版本要求（最低Android 5.0）
2. 检查是否启用了"未知来源"
3. 尝试卸载旧版本再安装

### 问题3：模块不生效
**症状**：LSPosed中显示未激活
**解决**：
1. 确认LSPosed已安装并激活
2. 重启手机
3. 检查Xposed日志

### 问题4：应用闪退
**症状**：打开应用立即关闭
**解决**：
1. 查看logcat日志
2. 检查AndroidManifest配置
3. 检查Activity类名是否正确

## 📞 获取帮助

如果以上步骤都失败：
1. **截图错误信息**
2. **提供GitHub仓库链接**
3. **描述具体问题**
4. **说明操作环境**

我会根据具体情况提供进一步帮助。

---

**重要提示**：
- 确保网络连接稳定
- 耐心等待GitHub Actions完成
- 首次编译可能需要下载依赖，时间较长
- 如果多次失败，可以尝试简化项目结构

**成功标志**：
1. GitHub Actions显示绿色✓
2. 能下载APK文件
3. APK能正常安装
4. 模块能在LSPosed中激活
5. 应用能正常启动

祝你好运！🎉